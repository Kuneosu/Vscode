App.onSay.Add(function(player,text){

    if(text == 'spped up'){
        player.moveSpped = 400;
    }
    if(text == 'spped down'){
        player.moveSpped = 30;
    }
    player.sendUpdated();
})