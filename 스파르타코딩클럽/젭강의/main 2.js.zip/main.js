App.onJoinPlayer.Add(function(player){

    let blood = ["A","B","O","AB"];
    let nth = Math.floor(Math.random()*blood.length)
    player.moveSpeed = 300;
    player.title = blood[nth];
    player.sendUpdated();
})