App.onJoinPlayer.Add(function(player){
    player.moveSpeed = 300;
    player.title = "덕배초코";
    player.sendUpdated();
})