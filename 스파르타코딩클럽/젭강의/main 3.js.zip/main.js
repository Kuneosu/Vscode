App.onSay.Add(function(player,text){
    App.showCenterLabel(text);
})

App.onJoinPlayer.Add(function(player){

    player.sprite = spartan;
    player.sendUpdated();
})

